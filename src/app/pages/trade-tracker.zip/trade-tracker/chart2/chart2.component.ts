import { Component, OnInit, Input } from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-chart2',
  templateUrl: './chart2.component.html',
  styleUrls: ['./chart2.component.scss']
})
export class chart2Component implements OnInit {

  @Input() inputData: any[];

  flipped: boolean = false;
  isLoaded: boolean = false;

  chartOption: EChartOption;


  xAxisData = [];
  data1 = [];
  data2 = [];


  constructor() { }

  ngOnInit() {
    this.setOption();
  }

  setOption() {
    this.chartOption = {
      animation: true,
      grid: {
        top: 60,
        bottom: 50,
        left: 50,
        right: 30,
      },
      //color: ["#b189ff", "#419ded", "#ffaa00"],
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
        }
    },
    legend: {
        data: ['BTCUSD', 'XRPUSD', 'GBPUSD', 'XAUUSD', 'JPYUSD'],        
        textStyle: {
          color: "#fff",
        },
        padding: [0, 0, 50, 0],
    },
    xAxis: [
        {
            type: 'category',
            boundaryGap: false,
            data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            axisLine: {
              lineStyle: {
                color: "#fff",
              }
            },
            axisLabel: {
              //color: "#fff",
              //fontSize: this.fontSize,
              // show: true,
            },
            axisTick: {
              show: false
            },
        },
    ],
    yAxis: [
        {
            type: 'value',
            axisLine: {
              lineStyle: {
                color: "#fff",
              }
            },
            axisLabel: {
              //color: "#fff",
              //fontSize: this.fontSize,
              // show: true,
            },
            axisTick: {
              show: false
            },
        }
    ],
    series: [
        {
            name: 'BTCUSD',
            type: 'line',
            stack: '总量',
            areaStyle: {},
            data: [120, 132, 101, 134, 90, 230, 210]
        },
        {
            name: 'XRPUSD',
            type: 'line',
            stack: '总量',
            areaStyle: {},
            data: [220, 182, 191, 234, 290, 330, 310]
        },
        {
            name: 'GBPUSD',
            type: 'line',
            stack: 'XAUUSD',
            areaStyle: {},
            data: [150, 232, 201, 154, 190, 330, 410]
        },
        {
            name: 'XAUUSD',
            type: 'line',
            stack: '总量',
            areaStyle: {},
            data: [320, 332, 301, 334, 390, 330, 320]
        },
        {
            name: 'JPYUSD',
            type: 'line',
            stack: '总量',
            label: {
                normal: {
                    show: true,
                    position: 'top'
                },
                //color: "#fff",
            },
            areaStyle: {},
            data: [820, 932, 901, 934, 1290, 1330, 1320]
        }
    ]
    }
  }
}
