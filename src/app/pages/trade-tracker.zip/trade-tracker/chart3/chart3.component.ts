import { Component, OnInit, Input } from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-chart3',
  templateUrl: './chart3.component.html',
  styleUrls: ['./chart3.component.scss']
})
export class chart3Component implements OnInit {

  @Input() inputData: any[];

  flipped: boolean = false;
  isLoaded: boolean = false;

  chartOption: EChartOption;


  xAxisData = [];
  data1 = [];
  data2 = [];


  constructor() { }

  ngOnInit() {
    this.setOption();
  }

  setOption() {
    this.chartOption = {
      animation: true,
      grid: {
        top: 50,
        bottom: 50,
        left: 50,
        right: 50,
      },
      color: ["#b189ff", "#419ded", "#ffaa00"],
      tooltip: {
        show: true,
        trigger: "axis",
        padding: 16,
        // formatter: (p: any) => {
        //   const time = p[0].axisValue;
        //   const left = this.pipe.transform(p[0].value);
        //   const right = "$" + p[1].value.toLocaleString('en-GB', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        //   return "Time: " + time + " <br> " + "Market value: " + "$" + left + " <br> " + "Price: " + right;
        // }
      },
      dataset: {
        dimensions: ['day', 'Total Trades', 'Total Wins', 'Pips Gained'],
        source: [
            {day: 'Monday', 'Total Trades': 53, 'Total Wins': 45, 'Pips Gained': 38},
            {day: 'Tuesday', 'Total Trades': 64, 'Total Wins': 51, 'Pips Gained': 44},
            {day: 'Wednesday', 'Total Trades': 45, 'Total Wins': 64, 'Pips Gained': 55},
            {day: 'Thursday', 'Total Trades': 48, 'Total Wins': 56, 'Pips Gained': 75},
            {day: 'Friday', 'Total Trades': 40, 'Total Wins': 51, 'Pips Gained': 88},
            {day: 'Saturday', 'Total Trades': 33, 'Total Wins': 85, 'Pips Gained': 66},
            {day: 'Sunday', 'Total Trades': 43, 'Total Wins': 65, 'Pips Gained': 77},
        ]
      },
      xAxis: [
        {
          type: "category",
          // axisLine: {
          //   show: true,
          // },
          axisLine: {
            lineStyle: {
              color: "#fff",
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: "#fff",
          },
        }
      ],
      yAxis: [
        {
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: "#fff",
            }
          },
          axisLabel: {
            color: "#fff",
          },
        },
        {
          type: "value",
          splitLine: {
            show: false,
            lineStyle: {
              type: "dashed"
            }
          },
          axisLine: {
            show: false
          },
          axisPointer: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: "#fff",            
          },
          position: "right"
        }
      ],
      legend: {
        show: true,
        textStyle: {
          color: '#fff',
        },
      },
      series: [
        {
          type: 'bar',
          id: "one",   
          barWidth: 40,
          barGap: "0%",                 
        },
      ],

    }
  }
}
