import { Component, OnInit } from '@angular/core';
import * as echarts from 'echarts';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-chart10',
  templateUrl: './chart10.component.html',
  styleUrls: ['./chart10.component.scss']
})
export class Chart10Component implements OnInit {

  chartOption: echarts.EChartOption;
  eChart: echarts.ECharts;

  now: any = +new Date(2018, 1, 1);
  oneDay = 24 * 3600 * 1000;
  DATA = [{ value: [9300,9900, 89000, 91000] }];
  DATES = [];

  low = Math.round(Math.random())*2350*Math.random();
  high = Math.round(Math.random())*5000*Math.random();
  price = Math.round(Math.random())*3500*Math.random();

  interval: Subscription;

  green: string = "#97f186";
  red: string = "#f0355c";

  constructor() { }

  ngOnInit() {
    this.now = new Date(+this.now + this.oneDay);
    this.DATES.push(this.now.toDateString());

    for (var i = 0; i < 100; i++) {
      this.setData(this.DATA[this.DATA.length - 1].value);
    }
    const rightGrid = this.checkScreen() ? "20%" : "10%";
    this.chartOption = this.setChartOption(rightGrid);
    this.interval = interval(1000).subscribe(r => {
      this.updateChartOption1();
      if (r % 60 === 0) {
        this.updateChartOption2();
      }
      if (r === 5) {
        this.updateChartOption2();
      }
    })
  }

  ngOnDestroy(): void {
    this.interval.unsubscribe();
  }

  checkScreen() {
    const landscape = window.innerWidth / window.innerHeight >= 1;
    const mobile = window.innerHeight < 480;
    if (!landscape || (landscape && mobile)) {
      return true;
    }
    return false;
  }

  setData(oldValue) {
    this.now = new Date(+this.now + this.oneDay);
    const v = Math.round(Math.random() * Math.random() * 3000);
    const o = oldValue[0] += this.trueOrFalse() ? +v : -v;
    const c = oldValue[0] += this.trueOrFalse() ? +v : -v;
    this.low = Math.min(this.low, c);
    this.high = Math.max(this.high, c);
    const data = {
      value: [o, c, this.low, this.high],
      itemStyle: {
        color: this.greenOrRed(o, c),
        color0: this.greenOrRed(o, c),
        borderColor: this.greenOrRed(o, c),
        borderColor0: this.greenOrRed(o, c)
      }
    }
    this.price = c;
    this.DATES.push(this.now.toDateString());
    this.DATA.push(data);
  }

  greenOrRed(v1, v2) {
    return v1 >= v2 ? this.red : this.green;
  }

  trueOrFalse() {
    return Math.round(Math.random())
  }

  setChartOption(rightGrid: string) {
    return {
      grid: {
        right: rightGrid
      },
      dataZoom: [
        {
          type: 'inside',
          start: 66,
          end: 100,
          maxSpan: 30,
          zoomLock: true
        }],
      xAxis: {
        axisLine: {
          lineStyle: {
            color: "#d1d1ff"
          }
        },
        splitLine: {
          show: false
        },
        axisPointer: {
          show: false
        },
        data: this.DATES
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '10%'],
        position: "right",
        axisLine: {
          lineStyle: {
            color: "#d1d1ff"
          }
        },
        splitLine: {
          show: false
        },
      },
      series: [{
        type: 'candlestick',
        showAllSymbol: false,
        hoverAnimation: false,
        data: this.DATA,
        markLine: {
          silent: true,
          symbol: "diamond",
          data: [
            {
              yAxis: this.price,
              symbol: "none",
              lineStyle: {
                color: "#d1d1ff",
                width: 1
              },
              label: {
                position: "end",
                backgroundColor: "#d1d1ff",
                color: "#6f42c1",
                padding: 8
              }
            }
          ]
        } as any
      }]
    } as echarts.EChartOption;
  }

  updateChartOption1() {
    var d: any = this.DATA[this.DATA.length - 1];
    var v = Math.round(Math.random() * 500);

    d.value[1] += this.trueOrFalse() ? +v : -v;
    this.low = Math.min(this.low, d.value[1]);
    this.high = Math.max(this.high, d.value[1]);
    d.value[2] = this.low;
    d.value[3] = this.high;

    this.price = d.value[1];

    d.itemStyle = {
      color: this.greenOrRed(d.value[0], d.value[1]),
      color0: this.greenOrRed(d.value[0], d.value[1]),
      borderColor: this.greenOrRed(d.value[0], d.value[1]),
      borderColor0: this.greenOrRed(d.value[0], d.value[1]),
    }

    this.DATA[this.DATA.length - 1] = d;

    const el = document.getElementById("chart") as HTMLDivElement;
    el ? echarts.getInstanceByDom(el).setOption({
      series: [{
        data: this.DATA,
        markLine: {
          silent: true,
          symbol: "diamond",
          animation: false,
          data: [
            {
              yAxis: this.price,
              symbol: "none",
              lineStyle: {
                width: 1,
                color: "#d1d1ff"
              },
              label: {
                position: "end",
                backgroundColor: "#d1d1ff",
                color: "#6f42c1",
                padding: 8,
                formatter: (v) => {
                  return `$${v.value},00`
                }
              }
            }
          ]
        } as any
      }]
    }) : "";
  }

  updateChartOption2() {
    const d = this.DATA[this.DATA.length - 1].value;
    this.setData(d);
    const el = document.getElementById("chart") as HTMLDivElement;
    el ? echarts.getInstanceByDom(el).setOption({
      xAxis: {
        data: this.DATES
      },
      series: [{
        data: this.DATA,
        markLine: {
          silent: true,
          symbol: "diamond",
          animation: false,
          data: [
            {
              yAxis: this.price,
              symbol: "none",
              lineStyle: {
                width: 1,
                color: "#d1d1ff"
              },
              label: {
                show: true,
                position: "end",
                backgroundColor: "#d1d1ff",
                color: "#6f42c1",
                padding: 8
              }
            }
          ]
        } as any
      }]
    }) : "";
  }

}